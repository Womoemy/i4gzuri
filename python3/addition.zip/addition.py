print("Enter two numbers you want to add!")

num_1 = input("First number: ")
num_2 = input("Second number: ")

num_1 = int(num_1)
num_2 = int(num_2)

sum = num_1 + num_2

print("Sum of " + str(num_1) + " and " + str(num_2) + " = " + str(sum))